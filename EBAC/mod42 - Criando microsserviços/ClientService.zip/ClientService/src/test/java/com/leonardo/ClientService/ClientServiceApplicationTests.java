package com.leonardo.ClientService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
